var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Entidades;
(function (Entidades) {
    var Ropa = /** @class */ (function () {
        function Ropa(codigo, nombre, precio) {
            this.codigo = codigo;
            this.nombre = nombre;
            this.precio = precio;
        }
        Ropa.prototype.ropaToString = function () {
            return "\"codigo\":" + this.codigo + ",\"nombre\":\"" + this.nombre + "\",\"precio\":" + this.precio;
        };
        return Ropa;
    }());
    Entidades.Ropa = Ropa;
    var Campera = /** @class */ (function (_super) {
        __extends(Campera, _super);
        function Campera(codigo, nombre, precio, talle, color, foto) {
            var _this = _super.call(this, codigo, nombre, precio) || this;
            _this.talle = talle;
            _this.color = color;
            _this.foto = foto;
            return _this;
        }
        Campera.prototype.ToJSON = function () {
            var retorno = "{" + this.ropaToString() + ",\"talle\":\"" + this.talle + "\",\"color\":\"" + this.color + "\",\"foto\":\"" + this.foto + "\"}";
            return JSON.parse(retorno);
        };
        return Campera;
    }(Ropa));
    Entidades.Campera = Campera;
})(Entidades || (Entidades = {}));
///<reference path="../node_modules/@types/jquery/index.d.ts"/>
var Test;
(function (Test) {
    var Manejadora = /** @class */ (function () {
        function Manejadora() {
        }
        Manejadora.AgregarCampera = function () {
            Manejadora.AdministrarSpinner(true);
            var codigo = $("#txtCodigo").val();
            var nombre = $("#txtNombre").val();
            var precio = $("#txtPrecio").val();
            var talle = $("#txtTalle").val();
            var color = $("#cboColores").val();
            var foto = document.getElementById("foto");
            var form = new FormData();
            var miCampera = new Entidades.Campera(codigo, nombre, precio, talle, color, foto.files[0].name);
            form.append("caso", "agregar");
            form.append("foto", foto.files[0]);
            form.append("cadenaJson", JSON.stringify(miCampera.ToJSON()));
            $.ajax({
                type: 'POST',
                url: "./BACKEND/Administrar.php",
                dataType: "text",
                cache: false,
                contentType: false,
                processData: false,
                data: form,
                async: true
            })
                .done(function (resultado) {
                Manejadora.AdministrarSpinner(false);
                console.log(resultado);
                Manejadora.LimpiarForm();
            })
                .fail(function (jqXHR, textStatus, errorThrown) {
                alert(jqXHR.responseText + "\n" + textStatus + "\n" + errorThrown);
            });
        };
        Manejadora.MostrarCamperas = function () {
            Manejadora.AdministrarSpinner(true);
            $.ajax({
                type: 'POST',
                url: "./BACKEND/administrar.php",
                dataType: "text",
                data: "caso=mostrar",
                async: true
            })
                .done(function (resultado) {
                Manejadora.AdministrarSpinner(false);
                var jsonMuestro = JSON.parse(resultado);
                var tabla = "<table border=5><tr><td>CODIGO</td><td>NOMBRE</td><td>PRECIO</td><td>TALLE</td><td>COLOR</td><td>FOTO</td><td>ACCIONES</td></tr>";
                for (var i = 0; i < jsonMuestro.length; i++) {
                    tabla += "<tr><td>" + jsonMuestro[i].codigo + "</td><td>" + jsonMuestro[i].nombre + "</td><td>" + jsonMuestro[i].precio + "</td><td>" + jsonMuestro[i].talle + ("</td><td>" + jsonMuestro[i].color + "</td>");
                    tabla += "<td><img src=\"./BACKEND/fotos/" + jsonMuestro[i].foto + "\" width='50px' height='50px'></td>";
                    tabla += "<td><input type=\"button\" value=\"Eliminar\" onclick='Test.Manejadora.EliminarCampera(" + JSON.stringify(jsonMuestro[i]) + ")'>";
                    tabla += "<input type=\"button\" value=\"Modificar\" onclick='Test.Manejadora.ModificarCampera(" + JSON.stringify(jsonMuestro[i]) + ")'></td></tr>";
                }
                tabla += "</table>";
                $("#divTabla").html(tabla);
            })
                .fail(function (jqXHR, textStatus, errorThrown) {
                alert(jqXHR.responseText + "\n" + textStatus + "\n" + errorThrown);
            });
        };
        Manejadora.EliminarCampera = function (obj) {
            if (confirm("Desea eliminar codigo:" + obj.codigo + ", talle:" + obj.talle)) {
                $.ajax({
                    type: 'POST',
                    url: "./BACKEND/administrar.php",
                    dataType: "text",
                    data: "caso=eliminar&cadenaJson=" + JSON.stringify(obj),
                    async: true
                })
                    .done(function (resultado) {
                    console.log(resultado);
                    Manejadora.MostrarCamperas();
                })
                    .fail(function (jqXHR, textStatus, errorThrown) {
                    alert(jqXHR.responseText + "\n" + textStatus + "\n" + errorThrown);
                });
            }
        };
        Manejadora.ModificarCampera = function (obj) {
            console.log(obj);
            $("#txtCodigo").val(obj.codigo);
            $("#txtCodigo").prop("disabled", true);
            $("#txtNombre").val(obj.nombre);
            $("#txtPrecio").val(obj.precio);
            $("#txtTalle").val(obj.talle);
            $("#cboColores").val(obj.color);
            $("#btn-agregar").val("Modificar");
            $("#btn-agregar").prop("onclick", null).off("click");
            $("#btn-agregar").click(function () {
                Manejadora.AdministrarSpinner(true);
                var codigo = $("#txtCodigo").val();
                var nombre = $("#txtNombre").val();
                var precio = $("#txtPrecio").val();
                var talle = $("#txtTalle").val();
                var color = $("#cboColores").val();
                var foto = document.getElementById("foto");
                var form = new FormData();
                var miCampera = new Entidades.Campera(codigo, nombre, precio, talle, color, foto.files[0].name);
                form.append("foto", foto.files[0]);
                form.append("cadenaJson", JSON.stringify(miCampera.ToJSON()));
                form.append("caso", "modificar");
                $.ajax({
                    type: 'POST',
                    url: "./BACKEND/administrar.php",
                    dataType: "text",
                    cache: false,
                    contentType: false,
                    processData: false,
                    data: form,
                    async: true
                })
                    .done(function (resultado) {
                    Manejadora.AdministrarSpinner(false);
                    console.log(resultado);
                    var objRetorno = JSON.parse(resultado);
                    if (objRetorno.TodoOK) {
                        Manejadora.LimpiarForm();
                        Manejadora.MostrarCamperas();
                    }
                })
                    .fail(function (jqXHR, textStatus, errorThrown) {
                    alert(jqXHR.responseText + "\n" + textStatus + "\n" + errorThrown);
                });
            });
        };
        Manejadora.FiltrarCamperasPorColor = function () {
            Manejadora.AdministrarSpinner(true);
            $.ajax({
                type: 'POST',
                url: "./BACKEND/administrar.php",
                dataType: "text",
                data: "caso=mostrar",
                async: true
            })
                .done(function (resultado) {
                Manejadora.AdministrarSpinner(false);
                var jsonMuestro = JSON.parse(resultado);
                var tabla = "<table border=5><tr><td>CODIGO</td><td>NOMBRE</td><td>PRECIO</td><td>TALLE</td><td>COLOR</td><td>FOTO</td><td>ACCIONES</td></tr>";
                var color = $("#cboColores").val();
                console.log(color);
                for (var i = 0; i < jsonMuestro.length; i++) {
                    if (color == jsonMuestro[i].color) {
                        tabla += "<tr><td>" + jsonMuestro[i].codigo + "</td><td>" + jsonMuestro[i].nombre + "</td><td>" + jsonMuestro[i].precio + "</td><td>" + jsonMuestro[i].talle + ("</td><td>" + jsonMuestro[i].color + "</td><td><img src=\"./BACKEND/fotos/" + jsonMuestro[i].pathFoto + "\" width='50px' height='50px'></td>");
                        tabla += "<td><input type=\"button\" value=\"Eliminar\" onclick='PrimerParcial.Manejadora.EliminarTelevisor(" + JSON.stringify(jsonMuestro[i]) + ")'>";
                        tabla += "<input type=\"button\" value=\"Modificar\" onclick='PrimerParcial.Manejadora.ModificarTelevisor(" + JSON.stringify(jsonMuestro[i]) + ")'></td></tr>";
                    }
                }
                tabla += "</table>";
                $("#divTabla").html(tabla);
            })
                .fail(function (jqXHR, textStatus, errorThrown) {
                alert(jqXHR.responseText + "\n" + textStatus + "\n" + errorThrown);
            });
        };
        Manejadora.CargarColoresJSON = function () {
            Manejadora.AdministrarSpinner(true);
            $.ajax({
                type: 'POST',
                url: "./BACKEND/administrar.php",
                dataType: "text",
                data: "caso=colores",
                async: true
            })
                .done(function (resultado) {
                Manejadora.AdministrarSpinner(false);
                var jsonMuestro = JSON.parse(resultado);
                Manejadora.LimpiarForm();
                $("#cboColores").empty();
                for (var i = 0; i < jsonMuestro.length; i++) {
                    $("#cboColores").append(new Option(jsonMuestro[i].descripcion));
                }
            })
                .fail(function (jqXHR, textStatus, errorThrown) {
                alert(jqXHR.responseText + "\n" + textStatus + "\n" + errorThrown);
            });
        };
        Manejadora.LimpiarForm = function () {
            $("#txtCodigo").val('');
            $("#txtTalle").val('');
            $("#txtNombre").val('');
            $("#txtPrecio").val('');
            $("#foto").val('');
            $("#cboColores").val("Azul");
        };
        Manejadora.AdministrarSpinner = function (mostrar) {
            var gif = "./BACKEND/gif-load.gif";
            var div = $("#divSpinner"); //<HTMLDivElement> document.getElementById("divGif");
            var img = $("#imgSpinner"); //<HTMLImageElement> document.getElementById("imgGif");
            if (mostrar) {
                div.css("display", "block"); //div.style.display = "block";
                div.css("top", "50%"); //div.style.top = "50%";
                div.css("left", "45%"); //div.style.left = "45%"
                img.attr("src", gif); //img.src = gif;
            }
            else {
                div.css("display", "block"); //div.style.display = "none";
                img.attr("src", ""); //img.src = "";
            }
        };
        return Manejadora;
    }());
    Test.Manejadora = Manejadora;
})(Test || (Test = {}));
