var a:string="Hola mundo";
var b:string="Puedo mostrar 'comillas simples'";
var c:string='Y comillas "dobles"';

console.log(`${a}\n${b}\n${c}`);