var a = "Hola mundo";
var b = "Puedo mostrar 'comillas simples'";
var c = 'Y comillas "dobles"';
console.log(a + "\n" + b + "\n" + c);
