function Cubo(numero) {
    return Math.pow(numero, 3);
}
function MostrarCubo() {
    console.log(Cubo(4));
}
MostrarCubo();
