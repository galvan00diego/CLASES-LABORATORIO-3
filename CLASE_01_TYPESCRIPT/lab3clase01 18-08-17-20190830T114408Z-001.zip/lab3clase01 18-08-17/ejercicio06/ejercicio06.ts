function Cubo(numero:number)
{
    return Math.pow(numero,3);
}
function MostrarCubo()
{
    console.log(Cubo(4));
}

MostrarCubo();