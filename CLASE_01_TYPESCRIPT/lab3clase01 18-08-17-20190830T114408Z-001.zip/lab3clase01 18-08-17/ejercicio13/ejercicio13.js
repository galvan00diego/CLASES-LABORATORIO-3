function smith(sum, facts) {
    if (sum == facts)
        return "El numero es Smith";
    else
        return "El numero NO es Smith";
}
function factoresPrimos(num) {
    var suma = 0;
    var divisor = 2;
    while (divisor <= num) {
        if (num % divisor == 0) {
            suma = divisor + suma;
            var cociente = num / divisor;
            num = cociente;
        }
        divisor = divisor + 1;
    }
    return suma;
}
function sumNumeros(num) {
    var valor1 = num % 10, valor2 = num / 10, sumValores = valor1 + valor2;
    return sumValores;
}
var sum = sumNumeros(378);
var facts = factoresPrimos(378);
var smithFin = smith(sum, facts);
console.log(smithFin);
