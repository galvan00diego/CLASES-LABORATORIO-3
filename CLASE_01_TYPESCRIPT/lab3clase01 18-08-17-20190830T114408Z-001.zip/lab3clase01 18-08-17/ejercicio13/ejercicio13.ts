function smith(sum:number, facts:number):string
{  
   if(sum == facts) 
    return "El numero es Smith"; 
   else
    return "El numero NO es Smith"; 
} 

function factoresPrimos(num:number){ 
    
   var suma = 0; 
   var divisor = 2; 
   while (divisor <= num){ 
       if(num % divisor == 0){ 
           suma = divisor + suma; 
               var cociente = num / divisor; 
           num = cociente; 
           } 
   divisor = divisor + 1; 
   } 
   return suma; 
} 

function sumNumeros(num:number){ 
   var valor1 = num % 10, 
       valor2 = num / 10, 
       sumValores = valor1 + valor2; 
   
   return sumValores; 
} 


var sum:number = sumNumeros(378);
var facts:number = factoresPrimos(378); 
var smithFin:string = smith(sum, facts); 
console.log(smithFin); 