function Funcion(numero, palabra) {
    if (palabra != null) {
        var i = 1;
        while (i <= numero) {
            i++;
            console.log(palabra);
        }
    }
    else {
        var x = numero.toString();
        var f = x.length;
        var cadena = "";
        while (f >= 0) {
            cadena = cadena + x.charAt(f);
            f--;
        }
        console.log(cadena);
    }
}
Funcion(6, "Hola");
Funcion(754);
