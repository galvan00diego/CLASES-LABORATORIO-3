"use strict";
console.log("hola mundo");
//# sourceMappingURL=miarchivo.js.map