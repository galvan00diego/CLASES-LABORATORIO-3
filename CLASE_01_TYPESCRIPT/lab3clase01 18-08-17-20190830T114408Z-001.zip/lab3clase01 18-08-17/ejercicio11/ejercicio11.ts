function Palindromo(cadena:string):void
{
    var cadenaSinEsp:string="";
    var cadenaInv:string="";
    //CONVERTIMOS TODA LA CADENA A LETRAS MINUSCULAS
    cadena=cadena.toLocaleLowerCase();
    var array:string[]=cadena.split(" ");
    //QUITAMOS LOS ESPACIOS A LA CADENA
    array.forEach(element => {
        cadenaSinEsp+=element;
    });
    //INVERTIMOS CADENA
    var x:number=cadenaSinEsp.length;
    while (x>=0) 
    {
        cadenaInv= cadenaInv + cadenaSinEsp.charAt(x);
        x--;
    }
    //COMPARAMOS CADENAS
    if(cadenaSinEsp==cadenaInv)
        console.log(`La cadena "${cadena}" es un palindromo`);
    else
        console.log(`La cadena "${cadena}" no es un palindromo`);
}
Palindromo("cadena con espacios");
Palindromo("Luz Azul");
Palindromo("Somos o no Somos");