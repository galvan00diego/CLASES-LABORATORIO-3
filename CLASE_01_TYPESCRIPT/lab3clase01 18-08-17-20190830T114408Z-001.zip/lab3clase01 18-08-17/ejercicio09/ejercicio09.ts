function Diez(fac:number):void
{
    if(fac>=0)
        {
            if(fac!=0)
                {
                    for(var i=fac-1;i>0;i--)
                        {           
                                fac*=i;
                        }
                        console.log(fac);
                }
                else
                    console.log(1);
        }
        else
            {
                console.log(Math.pow(fac,3));
            }
}

Diez(5);