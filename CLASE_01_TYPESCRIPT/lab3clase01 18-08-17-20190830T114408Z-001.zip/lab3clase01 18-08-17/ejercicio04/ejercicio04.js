function Espar(numero) {
    if (numero % 2 == 0) {
        console.log("El numero " + numero + " es par.");
    }
    else {
        console.log("El numero " + numero + " es impar.");
    }
}
Espar(12);
Espar(3);
