"use strict";
function Cadena(cadena) {
    if (cadena === cadena.toLocaleUpperCase())
        console.log("La cadena esta formada por mayúsculas.");
    else if (cadena === cadena.toLocaleLowerCase())
        console.log("La cadena esta formada por minúsculas.");
    else
        console.log("La cadena esta formada por mayúsculas y minúsculas.");
}
Cadena("La cadena combinada");
Cadena("CADENA MAYUSCULAS");
Cadena("cadena minúsculas");
//# sourceMappingURL=ejercicio10.js.map