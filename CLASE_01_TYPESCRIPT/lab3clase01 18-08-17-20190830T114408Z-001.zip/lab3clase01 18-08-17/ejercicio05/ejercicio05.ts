var nombre:string="DIEGO";
var apellido:string="galvan";

function MostrarNombreApellido(n:string,a:string)
{
    var apeMayus:string=a.toLocaleUpperCase();
    var nomMayus:string=n.charAt(0).toLocaleUpperCase()+nombre.substr(1).toLocaleLowerCase();
    console.log(`${apeMayus}, ${nomMayus}`);
}
MostrarNombreApellido(nombre,apellido);