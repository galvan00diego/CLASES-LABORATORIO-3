function Primos() {
    var arr = [];
    var e = 0;
    for (var i = 1; arr.length < 20; i++) {
        for (var f = 1; f <= i; f++) {
            if (i % f == 0)
                e++;
            if (f == i) {
                if (e == 2) {
                    arr.push(i);
                    e = 0;
                }
                else
                    e = 0;
            }
        }
    }
    arr.forEach(function (element) {
        console.log(element);
    });
}
Primos();
