/*
Aries (21/3 - 20/4)
Tauro (21/4 - 20/5)
Géminis (21/5 - 20/6)
Cáncer (21/6 - 20/7)
Leo (21/7 - 21/8)
Virgo (22/8 - 22/9)
Libra (23/9 - 22/10)
Escorpio (23/10 - 22/11)
Sagitario (23/11 - 20/12)
Capricornio (21/12 - 19/1)
Acuario (20/1 - 18/2)
Piscis (19/2 - 20/3)*/
function Zodiaco(fecha:string):void
{
    var array:string[]=fecha.split("-");
    if(parseInt(array[1])==3 && parseInt(array[0])>=21 || parseInt(array[1])==4 && parseInt(array[0])<=20)
        {
            console.log("Tu signo del zodiaco es Aries");
        }
    if(parseInt(array[1])==4 && parseInt(array[0])>=21 || parseInt(array[1])==5 && parseInt(array[0])<=20)
        {
            console.log("Tu signo del zodiaco es Tauro");
        }
    if(parseInt(array[1])==5 && parseInt(array[0])>=21 || parseInt(array[1])==6 && parseInt(array[0])<=20)
        {
            console.log("Tu signo del zodiaco es Géminis");
        }
    if(parseInt(array[1])==6 && parseInt(array[0])>=21 || parseInt(array[1])==7 && parseInt(array[0])<=20)
        {
            console.log("Tu signo del zodiaco es Cáncer");
        }
    if(parseInt(array[1])==7 && parseInt(array[0])>=21 || parseInt(array[1])==8 && parseInt(array[0])<=20)
        {
            console.log("Tu signo del zodiaco es Leo");
        }     
    if(parseInt(array[1])==8 && parseInt(array[0])>=21 || parseInt(array[1])==9 && parseInt(array[0])<=20)
        {
            console.log("Tu signo del zodiaco es Virgo");
        }
    if(parseInt(array[1])==9 && parseInt(array[0])>=21 || parseInt(array[1])==10 && parseInt(array[0])<=20)
        {
            console.log("Tu signo del zodiaco es Libra");
        }
    if(parseInt(array[1])==10 && parseInt(array[0])>=21 || parseInt(array[1])==11 && parseInt(array[0])<=20)
        {
            console.log("Tu signo del zodiaco es Escorpio");
        }
    if(parseInt(array[1])==11 && parseInt(array[0])>=21 || parseInt(array[1])==12 && parseInt(array[0])<=20)
        {
            console.log("Tu signo del zodiaco es Sagitario");
        }
    if(parseInt(array[1])==12 && parseInt(array[0])>=21 || parseInt(array[1])==1 && parseInt(array[0])<=19)
        {
            console.log("Tu signo del zodiaco es Capricornio");
        }
    if(parseInt(array[1])==1 && parseInt(array[0])>=20 || parseInt(array[1])==2 && parseInt(array[0])<=18)
        {
            console.log("Tu signo del zodiaco es Acuario");
        }
    if(parseInt(array[1])==2 && parseInt(array[0])>=19 || parseInt(array[1])==3 && parseInt(array[0])<=20)
        {
            console.log("Tu signo del zodiaco es Piscis");
        }        
}

Zodiaco("21-03-1992");
Zodiaco("20-05-2003");
Zodiaco("12-11-1965");
Zodiaco("12-01-1970");