var meses:string[]=["Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio",
                    "Agosto","Septiembre","Octubre","Noviembre","Diciembre"];
for(var i=0;i<meses.length;i++)
{
    console.log(`${i+1} - ${meses[i]}`);
}