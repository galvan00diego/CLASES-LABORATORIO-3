///<reference path="../node_modules/@types/jquery/index.d.ts"/>
$(document).ready(function () {

    $("#btnAceptar").click(function()
    {
        let correo:any=$("#txtCorreo").val();
        let clave:any=$("#txtClave").val();
        let form:FormData=new FormData();
        form.append("correo",correo);   form.append("clave",clave);
    
        $.ajax({
            type: 'GET',
            url: "./asd/api.php/home",
            dataType: "text",
            cache: false,
            contentType: false,
            processData: false,
            data:form,
            async: true
        })
        .done(function (resultado) {
            console.log(resultado);
            //let obj:any=JSON.parse(resultado);
            //$("#divMensaje").addClass("Exito");
            //$("#divMensaje").html(`<p>Bienvenido <br>${obj.datos.nombre}</p>`);
            
            
       
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            //alert(jqXHR.responseText + "\n" + textStatus + "\n" + errorThrown);
            //console.log(jqXHR.responseText);
            $("#divMensaje").addClass("<p>Error</p>");
            $("#divMensaje").html(jqXHR.responseText);
        });    
        
    });
});