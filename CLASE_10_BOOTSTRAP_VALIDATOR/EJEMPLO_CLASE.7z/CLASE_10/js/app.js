$(document).ready(function() {

    $('#loginForm').bootstrapValidator({

        message: 'El valor no es válido',
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            email: {
                validators: {
                    notEmpty: {
                        message: 'El campo Email es requerido!'
                    },
                    emailAddress: {
                        message: 'El campo email no posee un formato válido!'
                    }
                }
            },
            password: {
                validators: {
                    notEmpty: {
                        message: 'La contraseña es requerida!!!'
                    },
                    stringLength: {
                        min: 6,
                        max: 20,
                        message: 'Por favor, ingrese entre 6 y 20 caracteres!!!'
                    }
                }
            }
        }
    })
    .on('success.form.bv', function (e) {
        e.preventDefault();
        // alert("Bienvenido");
        // console.log(e.message);
        // window.location.href="index.html";

        var correo = $("#email").val();
        var clave = $("#password").val();
        var form = new FormData();
        form.append("email", correo);
        form.append("password", clave);
        $.ajax({
            type: 'POST',
            url: "./api.php/login/",
            dataType: "text",
            cache: false,
            contentType: false,
            processData: false,
            data: form,
            async: true
        })
            .done(function (resultado) {
            console.log(resultado);
            let token=JSON.parse(resultado);
            localStorage.setItem("token",token.token);
            window.location.href="index.html";
            //let obj:any=JSON.parse(resultado);
            //$("#divMensaje").addClass("Exito");
            //$("#divMensaje").html(`<p>Bienvenido <br>${obj.datos.nombre}</p>`);
        })
            .fail(function (jqXHR, textStatus, errorThrown) {
            //alert(jqXHR.responseText + "\n" + textStatus + "\n" + errorThrown);
            //console.log(jqXHR.responseText);
            $("#divMensaje").addClass("<p>Error</p>");
            $("#divMensaje").html(jqXHR.responseText);
        });

    });
});