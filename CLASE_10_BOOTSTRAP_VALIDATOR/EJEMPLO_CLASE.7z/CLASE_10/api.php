<?php

use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

require_once 'vendor/autoload.php';
require_once 'AutentificadorJWT.php';

$config['displayErrorDetails'] = true;
$config['addContentLengthHeader'] = false;


$app = new \Slim\App(["settings" => $config]);



$app->get('/home', function (Request $request, Response $response) {    
    $response->getBody()->write("GET => Bienvenido!!! a SlimFramework");
    return $response;

});

$app->group('/login', function(){
  
     $this->post('/', function(Request $request, Response $response){
               
            $ArrayDeParametros = $request->getParsedBody();
    
            $objeto= new stdclass();
            $objeto->nombre=$ArrayDeParametros['email'];
            $objeto->apellido=$ArrayDeParametros['password'];
            $retorno=new stdClass();
            $retorno->token=AutentificadorJWT::CrearToken($objeto);
            $retorno->exito=TRUE;
            return $response->withJson($retorno, 200);
        });
});

$app->run();
